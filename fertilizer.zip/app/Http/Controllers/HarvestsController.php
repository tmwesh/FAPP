<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App;

class HarvestsController extends Controller
{
    public function index()
    {

    	$harvests = App\Harvest::orderBy('datetime', 'desc')
    							->with('sales')
    							->get();

    	return view('harvests.harvests', compact('harvests'));
    }


    public function get(App\Harvest $harvest)
    {
    	return $harvest;
    }


    public function store(Request $request)
    {
    	$this->validate($request, [
    			'quantity' => 'required',
    			'mass' => 'required',
    			'date' => 'required'
    		]);

    	if($request->id) {
    		$harvest = App\Harvest::findOrFail($request->id);
    	} else {
    		$harvest = new App\Harvest;


    		$harvest->user_id = auth()->id();
    	}


    	$harvest->quantity = $request->quantity;
    	$harvest->mass = $request->mass;
    	$harvest->datetime = $request->date;
    	$harvest->description = $request->description;


    	$harvest->save();


    	return [
    				'status' => 1,
    				'message' => 'Success',
    				'harvest' => $harvest
    			];
    }
}

