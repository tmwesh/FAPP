<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App;

class ProductsController extends Controller
{
    public function index()
    {
    	$products = App\Product::get();

    	return view('products.products', compact('products'));
    }


    public function get(App\Product $product)
    {
    	return $product;
    }


    public function view(App\Product $product)
    {
    	return view('products.view', compact('product'));
    }





    public function store(Request $request)
    {
    	// return $request->all();

    	$this->validate($request, [
    			'sku' => 'required|unique:products,sku,'.$request->get('id', 0),
    			'name' => 'required',
    			'unit_of_measure_id' => 'required',
    			'packaging' => 'required',
    			'unit_per_packaging' => 'required'
    		]);



    	if($request->id) {
    		$product = App\Product::findOrFail($request->id);
    	} else {
    		$product = new App\Product;


    		$product->user_id = auth()->id();
    	}



    	$product->sku = $request->sku;
    	$product->name = $request->name;
    	$product->unit_of_measure_id = $request->unit_of_measure_id;
    	$product->packaging = $request->packaging;
    	$product->unit_per_packaging = $request->unit_per_packaging;
    	$product->description = $request->description;



    	$product->save();


    	return [
    		'status' => 1,
    		'message' => 'Succes',
    		'product' => $product
    	];
    }


    public function activate(Request $request, App\Product $product)
    {

        $product->active = $product->active ? 0: 1;

        $product->save();

        if($request->ajax()) {
            return [
                'status' => 1,
                'message' => $product->active ? 'Activated': 'Deactivated',
                'active' => $product->active,
            ];
        }

        return back();
    }


    public function delete(Request $request, App\Product $product)
    {
        $product->delete();

        if($request->ajax()) {
            return [
                'status' => 1,
                'message' => 'Product deleted successfully'
            ];
            
        }

        return back();

    }
}
