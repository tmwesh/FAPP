<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App;

class CustomersController extends Controller
{
    public function index()
    {
    	$customers = App\Customer::get();

    	return view('customers.customers', compact('customers'));
    }


    public function get(App\Customer $customer)
    {
    	return $customer;
    }





    public function store(Request $request)
    {
    	// return $request->all();

    	$this->validate($request, [
    			'name' => 'required',
    			'email' => 'unique:customers,email,'.$request->get('id', 0),
    			'phone' => 'required|unique:customers,phone,'.$request->get('id', 0),
    			'location' => 'required'
    		]);



    	if($request->id) {
    		$customer = App\Customer::findOrFail($request->id);
    	} else {
    		$customer = new App\Customer;


    		$customer->user_id = auth()->id();
    	}



    	$customer->name = $request->name;
    	$customer->email = $request->email;
    	$customer->phone = $request->phone;
    	$customer->location = $request->location;
    	$customer->description = $request->description;



    	$customer->save();


    	return [
    		'status' => 1,
    		'message' => 'Succes',
    		'customer' => $customer
    	];
    }


    public function activate(Request $request, App\Customer $customer)
    {

        $customer->active = $customer->active ? 0: 1;

        $customer->save();

        if($request->ajax()) {
            return [
                'status' => 1,
                'message' => $customer->active ? 'Activated': 'Deactivated',
                'active' => $customer->active,
            ];
        }

        return back();
    }


    public function delete(Request $request, App\Customer $customer)
    {
        $customer->delete();

        if($request->ajax()) {
            return [
                'status' => 1,
                'message' => 'Customer deleted successfully'
            ];
            
        }

        return back();

    }
}
