<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App;


class FCSSController extends Controller
{
    public function index()
    {
    	$FCSS = App\FCSS::get();

    	return view('FCS.FCS', compact('FCSS'));
    }


    public function get(App\FCSS $FCSS)
    {
    	return $FCSS;
    }





    public function submit(Request $request)
    {
    	return $request->all();

    	$this->validate($request, [
    			'name' => 'required',
    			'email' => 'unique:f_c_s_s,email,'.$request->get('id', 0),
    			'phone' => 'required|unique:f_c_s_s,phone,'.$request->get('id', 0),
    			'location' => 'required'
    		]);



    	if($request->id) {
    		$FCSS = App\FCSS::findOrFail($request->id);
    	} else {
    		$FCSS = new App\FCSS;


    		// $farmer->user_id = auth()->id();
    	}



    	$FCS->name = $request->name;
    	$FCS->email = $request->email;
    	$FCS->phone = $request->phone;
    	$FCS->location = $request->location;
        $FCS->compliance_no = $request->compliance_no;
        $FCS->bond_id = $request->bond_id;
    	//$FCS->description = $request->description;



    	$FCS->save();


    	return [
    		'status' => 1,
    		'message' => 'Succes',
    		'FCS' => $FCS
    	];
    }


    public function activate(Request $request, App\Farmer $farmer)
    {

        $farmer->active = $farmer->active ? 0: 1;

        $farmer->save();

        if($request->ajax()) {
            return [
                'status' => 1,
                'message' => $farmer->active ? 'Activated': 'Deactivated',
                'active' => $farmer->active,
            ];
        }

        return back();
    }


    public function delete(Request $request, App\Farmer $farmer)
    {
        $farmer->delete();

        if($request->ajax()) {
            return [
                'status' => 1,
                'message' => 'Farmer deleted successfully'
            ];
            
        }

        return back();

    }
}
