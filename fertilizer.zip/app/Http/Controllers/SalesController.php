<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App;

class SalesController extends Controller
{
   	public function harvest_sales(App\Harvest $harvest)
   	{
   		$harvest->load('sales.customer');

    	$customers = App\Customer::active()->get();


   		return view('harvests.sales', compact('harvest', 'customers'));
   	}


   	public function store(Request $request)
   	{
   		$this->validate($request, [
   				'harvest_id' => 'required',
   				'customer_id' => 'required',
   				'mass' => 'required',
   				'quantity' => 'required',
   				'cost' => 'required',
   				'date' => 'required|date',

   			]);


   		// return $request->all();
   		if($request->id) {
    		$sale = App\Sale::findOrFail($request->id);
    	} else {
    		$sale = new App\Sale;


    		$sale->user_id = auth()->id();
    		$sale->harvest_id = $request->harvest_id;
    	}


    	$sale->customer_id = $request->customer_id;
    	$sale->quantity = $request->quantity;
    	$sale->mass = $request->mass;
    	$sale->cost = $request->cost;
    	$sale->amount = $request->cost * $request->quantity;
    	$sale->datetime = $request->date;
    	$sale->description = $request->description;


    	$sale->save();


    	return [
    				'status' => 1,
    				'message' => 'Success',
    				'sale' => $sale
    			];
   	}
}
