<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App;

class CreditsController extends Controller
{
    public function index(Request $request)
    {

    	$credits = App\Credit::orderBy('datetime', 'desc')
    						->with('customer')
    						->get();


    	$customers = App\Customer::active()->get();

    	return view('credits.credits', compact('credits', 'customers'));
    }


    public function store(Request $request)
    {
    	$this->validate($request, [
    			'customer_id' => 'required',
    			'amount' => 'required',
    			'date' => 'required'
    		]);


    	$credit = new App\Credit;
    	$credit->user_id = auth()->id();


    	$credit->customer_id = $request->customer_id;
    	$credit->amount = $request->amount;
    	$credit->datetime = $request->date;
    	$credit->description = $request->description;


    	$credit->save();


    	return [
    				'status' => 1,
    				'message' => 'Success',
    				'credit' => $credit
    			];
    }
}
