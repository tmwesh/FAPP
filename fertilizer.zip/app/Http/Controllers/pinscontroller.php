<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class pinscontroller extends Controller
{
    //
}
