<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App;


class FarmersController extends Controller
{
    public function index()
    {
    	$farmers = App\Farmer::get();

    	return view('farmers.farmers', compact('farmers'));
    }


    public function get(App\Farmer $farmer)
    {
    	return $farmer;
    }





    public function store(Request $request)
    {
    	// return $request->all();

    	$this->validate($request, [
    			'name' => 'required',
    			'email' => 'unique:farmers,email,'.$request->get('id', 0),
    			'phone' => 'required|unique:farmers,phone,'.$request->get('id', 0),
    			'location' => 'required'
    		]);



    	if($request->id) {
    		$farmer = App\Farmer::findOrFail($request->id);
    	} else {
    		$farmer = new App\Farmer;


    		// $farmer->user_id = auth()->id();
    	}



    	$farmer->name = $request->name;
    	$farmer->email = $request->email;
    	$farmer->phone = $request->phone;
    	$farmer->location = $request->location;
        $farmer->size = $request->size;
        $farmer->national_id = $request->national_id;
    	$farmer->description = $request->description;



    	$farmer->save();


    	return [
    		'status' => 1,
    		'message' => 'Succes',
    		'farmer' => $farmer
    	];
    }


    public function activate(Request $request, App\Farmer $farmer)
    {

        $farmer->active = $farmer->active ? 0: 1;

        $farmer->save();

        if($request->ajax()) {
            return [
                'status' => 1,
                'message' => $farmer->active ? 'Activated': 'Deactivated',
                'active' => $farmer->active,
            ];
        }

        return back();
    }


    public function delete(Request $request, App\Farmer $farmer)
    {
        $farmer->delete();

        if($request->ajax()) {
            return [
                'status' => 1,
                'message' => 'Farmer deleted successfully'
            ];
            
        }

        return back();

    }
}
