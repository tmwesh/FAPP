<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App;

class ExpensesController extends Controller
{
    public function index()
    {

    	$expenses = App\Expense::orderBy('datetime', 'desc')
    							->get();

    	return view('expenses.expenses', compact('expenses'));
    }


    public function store(Request $request)
    {
    	$this->validate($request, [
    			'title' => 'required',
    			'amount' => 'required',
    			'description' => 'required',
    			'date' => 'required'
    		]);


    	$expense = new App\Expenses;
    	$expense->user_id = auth()->id();


    	$expense->title = $request->title;
    	$expense->amount = $request->amount;
    	$expense->datetime = $request->date;
    	$expense->description = $request->description;


    	$expense->save();


    	return [
    				'status' => 1,
    				'message' => 'Success',
    				'expense' => $expense
    			];
    }
}
