<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use Illuminate\Http\Request;


class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;



    public function toggle_active(Request $request, $id)
    {

    	$class = get_class($this);

    	$Model ='App\\' . str_replace('sController', '', substr($class, strrpos($class, '\\') + 1));


        $model = $Model::findOrFail($id);

        $model->active = ($model->active)? 0: 1;

        if($model->save()){
            $response = [
                'status' => 1,
                'message' => ($model->active)? 'Activeted': 'Deactivated',
                'active' => $model->active,
                'results' => $model
            ];
        } else {
            $response = [
                'status' => 0,
                'errors' => ['Failed: please try again']
            ];
        }


        return response()->json($response);
    }
}
