<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App;

class SettingsController extends Controller
{
    public function index()
    {

    	$sms_template = App\Variable::where('title', 'sms_template')->first()->value;

    	return view('settings.settings', compact('sms_template'));
    }


    public function store_sms_template(Request $request)
    {
    	$this->validate($request, ['sms_template' => 'required']);


    	$sms_template = App\Variable::where('title', 'sms_template')->first();


    	$sms_template->value = $request->sms_template;


    	$sms_template->save();


    	return [
    		'status' => 1,
    		'message' => 'Template saved successful',
    		
    	];
    }
}
