<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bond extends Model
{
    //
}
