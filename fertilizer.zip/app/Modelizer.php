<?php

namespace App;


trait Modelizer {
	public function scopeActive($q, $value = 1)
	{
		$q->where('active', $value);
	}
}