<?php /* C:\xampp\htdocs\kwema\resources\views/contribution-types/contribution-types.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Contribution Types</h4>
							<p class="card-category"><i>Count <?php echo e($types->count()); ?></i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Title</th>
                            <th class="text-right">Amount</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($type->title); ?></td>
                                <td class="text-right"><?php echo e(number_format($type->amount)); ?></td>
								<td class="text-center">
									<a href="/contribution-type/<?php echo e($type->id); ?>/edit" class="btn btn-sm btn-success edit" title="Edit" data-toggle="tooltip">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="/contribution-type/<?php echo e($type->id); ?>/activate"  class="activate btn btn-sm btn-<?php echo e($type->active ? 'warning': 'default'); ?>">
                                        <i class="fa fa-<?php echo e($type->active ? 'check': 'ban'); ?>"></i>
                                    </a>
                                    <?php echo $__env->make('includes.delete-button', ['url'=>'/contribution-type/'.$type->id.'/delete'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/contribution-type" class="submit" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Contribution Type</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<div class="form-group row">
                		<label for="title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Title')); ?></label>

                		<div class="col-md-6">
                			<input id="title" type="text" class="form-control" name="title" required autofocus>

                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="amount" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Amount')); ?></label>

                        <div class="col-md-6">
                            <input id="amount" type="number" class="form-control" name="amount" >

                        </div>
                    </div>
                	

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	<?php echo $__env->make('includes.spinner', ['size' => 15], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </button>
                </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>