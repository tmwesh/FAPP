<?php /* C:\xampp\htdocs\agris\resources\views/harvests/sales.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Harvest Sales</h4>
							<p class="card-category">
                                <i class="pr-2">Count: <?php echo e($harvest->sales->count()); ?>,</i>
                                <strong class="title">Mass: <?php echo e($harvest->mass); ?>,</strong>
                                <strong class="title">Sold: <?php echo e($harvest->sales->sum('quantity')); ?>&#47;<?php echo e($harvest->quantity); ?>,</strong>
                            </p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
                    <form method="post" action="/sale" class="submit">
    					<table class="table table-hover">
    						<thead class="text-info">
    							<th>#</th>
                                <th>Customer</th>
                                <th class="text-right">Mass (grams)</th>
    							<th class="text-right">Quantity</th>
                                <th class="text-right">Cost (KES)</th>
    							<th>Date</th>
                                <th>Description</th>
                                <th class="text-right">Amount</th>
    							<th class="text-center">Action</th>
    						</thead>
    						<tbody>
    							<?php $__currentLoopData = $harvest->sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    							<tr>
    								<td><?php echo e($sale->id); ?></td>
                                    <td><?php echo e($sale->customer->name); ?></td>
    								<td class="text-right"><?php echo e(number_format($sale->mass)); ?></td>
                                    <td class="text-right"><?php echo e(number_format($sale->quantity)); ?></td>
                                    <td class="text-right"><?php echo e(number_format($sale->cost)); ?></td>
                                    <td><?php echo e(substr($sale->datetime, 0, 10)); ?></td>
                                    <td><?php echo e($sale->description); ?></td>
                                    <td class="text-right"><?php echo e(number_format($sale->amount)); ?></td>
    								<td class="text-center">
                                                                                <a href="/sale/<?php echo e($sale->id); ?>/activate"  class="activate btn btn-sm btn-<?php echo e($sale->active ? 'warning': 'default'); ?>">
                                            <i class="fa fa-<?php echo e($sale->active ? 'check': 'ban'); ?>"></i>
                                        </a>
                                        
                                    </td>
    							</tr>
    							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>&nbsp;
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id">
                                        <input type="hidden" name="harvest_id" value="<?php echo e($harvest->id); ?>">
                                    </td>
                                    <td>
                                        <select name="customer_id" id="customer_id" class="selectpicker" data-live-search="true" required>
                                            <option selected disabled>Select Customer</option>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                                        </select>
                                    </td>
                                    <td><input type="number" value="250" class="form-control text-right" name="mass" placeholder="Mass" required></td>
                                    <td><input type="number" class="form-control text-right" name="quantity" placeholder="Quantity" required></td>
                                    <td><input type="number" class="form-control text-right" name="cost" placeholder="Cost" value="150" ></td>
                                    <td><input type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" name="date" placeholder="Date" required ></td>
                                    <td><input type="text" class="form-control" name="description" placeholder="Description" ></td>
                                    <td></td>
                                    <td>
                                        <button type="submit" class="btn btn-primary">
                                            Save
                                            <?php echo $__env->make('includes.spinner', ['size' => 10], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </button>
                                    </td>
                                </tr>
    						</tbody>
    					</table>
                    </form>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/sale" class="submit" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" >
            <input type="hidden" name="harvest_id" value="<?php echo e($harvest->id); ?>" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Sale</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label for="customer_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Customer')); ?></label>

                        <div class="col-md-6">
                            <select name="customer_id" id="customer_id" class="selectpicker" data-live-search="true" required>
                                <option selected disabled>Select Customer</option>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                            </select>
                        </div>
                    </div>

                	<div class="form-group row">
                		<label for="quantity" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Quantity')); ?></label>

                		<div class="col-md-6">
                			<input id="quantity" type="number" class="form-control" name="quantity" required autofocus>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="mass" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Mass (grams)')); ?></label>

                		<div class="col-md-6">
                			<input id="mass" type="number" value="250" class="form-control" name="mass" required>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="cost" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cost (KES)')); ?></label>

                		<div class="col-md-6">
                			<input id="cost" type="number" class="form-control" name="cost" value="150" >

                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="date" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date')); ?></label>

                        <div class="col-md-6">
                            <input id="date" type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" name="date" required >

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	<?php echo $__env->make('includes.spinner', ['size' => 15], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </button>
                </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>