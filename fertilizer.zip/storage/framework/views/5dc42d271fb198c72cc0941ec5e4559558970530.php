<?php /* C:\xampp\htdocs\kwema\resources\views/payments/payments.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Payments</h4>
							<p class="card-category"><i>Count <?php echo e($payments->count()); ?></i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Payment No.</th>
							<th>Member</th>
							<th>Type</th>
							<th class="text-right">Amount</th>
							<th>Date</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($payment->id); ?></td>
								<td><?php echo e($payment->member->name); ?></td>
                                <td><?php echo e($payment->contribution_type->title); ?></td>
                                <td class="text-right"><?php echo e(number_format($payment->amount)); ?></td>
                                <td><?php echo e(substr($payment->date, 0, 10)); ?></td>
								<td class="text-center">
									
                                    <a href="/payment/<?php echo e($payment->id); ?>/activate"  class="activate btn btn-sm btn-<?php echo e($payment->active ? 'warning': 'default'); ?>">
                                        <i class="fa fa-<?php echo e($payment->active ? 'check': 'ban'); ?>"></i>
                                    </a>
                                    
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/payment" class="submit" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Payment</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<div class="form-group row">
                		<label for="member_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Member')); ?></label>

                		<div class="col-md-6">
                			<select name="member_id" id="member_id" class="selectpicker" data-live-search="true" required>
                                <option selected disabled>Select Member</option>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($member->id); ?>"><?php echo e($member->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                            </select>
                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="contribution_type_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contribution Type')); ?></label>

                        <div class="col-md-6">
                            <select name="contribution_type_id" id="contribution_type_id" class="selectpicker contribution-type" required>
                                <option selected disabled>Select Contribution Type</option>
                                <?php $__currentLoopData = $contribution_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contribution_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($contribution_type->id); ?>" data-amount="<?php echo e($contribution_type->amount); ?>"><?php echo e($contribution_type->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                            </select>

                        </div>
                    </div>

                	<div class="form-group row">
                		<label for="amount" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Amount')); ?></label>

                		<div class="col-md-6">
                			<input id="amount" type="number" class="form-control contribution_amount" name="amount" required>
                            <span id="loan-payment-loader">
                                <?php echo $__env->make('includes.spinner', ['size' => 10], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </span>
                		</div>
                	</div>

                    <div class="form-group row">
                        <label for="date" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date')); ?></label>

                        <div class="col-md-6">
                            <input id="date" type="date" class="form-control" name="date" required>

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	<?php echo $__env->make('includes.spinner', ['size' => 15], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </button>
                </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>