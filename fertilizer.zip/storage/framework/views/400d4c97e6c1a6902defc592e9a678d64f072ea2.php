<?php /* C:\xampp\htdocs\kwema\resources\views/members/members.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Members</h4>
							<p class="card-category"><i>Count <?php echo e($members->count()); ?></i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Member No.</th>
                            <th class="text-center">SMS</th>
							<th>Name</th>
							<th>Phone</th>
							<th>Email</th>
							<th>Location</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($member->id); ?></td>
                                <td class="text-center">
                                    <a href="sms:+254<?php echo e(substr($member->phone, -9)); ?>?body=<?php echo e(strtr($sms_template, ['{name}' => $member->name, '{balance}' => 0])); ?>">
                                        <i class="material-icons">sms</i>
                                    </a>
                                </td>
								<td><?php echo e($member->name); ?></td>
								<td><a href="tel:<?php echo e($member->phone); ?>"><?php echo e($member->phone); ?></a></td>
								<td><a href="mailto:<?php echo e($member->email); ?>"><?php echo e($member->email); ?></a></td>
								<td><?php echo e($member->location); ?></td>
								<td class="text-center">
									<a href="/member/<?php echo e($member->id); ?>/edit" class="btn btn-sm btn-success edit" title="Edit" data-toggle="tooltip">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="/member/<?php echo e($member->id); ?>/activate"  class="activate btn btn-sm btn-<?php echo e($member->active ? 'warning': 'default'); ?>">
                                        <i class="fa fa-<?php echo e($member->active ? 'check': 'ban'); ?>"></i>
                                    </a>
                                    <?php echo $__env->make('includes.delete-button', ['url'=>'/member/'.$member->id.'/delete'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/member" class="submit" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Member</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<div class="form-group row">
                		<label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                		<div class="col-md-6">
                			<input id="name" type="text" class="form-control" name="name" required autofocus>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>

                		<div class="col-md-6">
                			<input id="email" type="email" class="form-control" name="email" required>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone')); ?></label>

                		<div class="col-md-6">
                			<input id="phone" type="tel" class="form-control" name="phone" required>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="location" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Location')); ?></label>

                		<div class="col-md-6">
                			<input id="location" type="tel" class="form-control" name="location" >

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	<?php echo $__env->make('includes.spinner', ['size' => 15], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </button>
                </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>