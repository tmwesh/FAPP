<?php /* C:\xampp\htdocs\kwema\resources\views/includes/sidebar.blade.php */ ?>
<div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
<!--
Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

Tip 2: you can also add an image using data-image tag
-->
<div class="logo">
    <a href="/" class="simple-text logo-normal">
        <?php echo e(config('app.name', 'Laravel')); ?>

    </a>
</div>
<div class="sidebar-wrapper">
    <ul class="nav">
        <li class="nav-item <?php echo e(Request::is('dashboard') ? 'active': ''); ?>">
            <a class="nav-link" href="/dashboard">
                <i class="material-icons">dashboard</i>
                <p>Dashboard</p>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('members') ? 'active': ''); ?>">
            <a class="nav-link" href="/members">
                <i class="material-icons">person</i>
                <p>Members</p>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('contribution-types') ? 'active': ''); ?>">
            <a class="nav-link" href="/contribution-types">
                <i class="material-icons">person</i>
                <p>Contribution Types</p>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('payments') ? 'active': ''); ?>">
            <a class="nav-link" href="/payments">
                <i class="material-icons">person</i>
                <p>Payments</p>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('loans') ? 'active': ''); ?>">
            <a class="nav-link" href="/loans">
                <i class="material-icons">person</i>
                <p>Loans</p>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('settings') ? 'active': ''); ?>">
            <a class="nav-link" href="/settings">
                <i class="material-icons">settings</i>
                <p>Settings</p>
            </a>
        </li>

    </ul>
</div>

</div>