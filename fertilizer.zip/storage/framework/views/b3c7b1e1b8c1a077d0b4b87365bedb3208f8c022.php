<?php /* C:\xampp\htdocs\LaravelNew\NCPB\resources\views/includes/delete-button.blade.php */ ?>
<form action="<?php echo e($url); ?>" method="post" class="ajaxDelete">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="_method" value="DELETE" >
    <button type="submit" class="btn btn-danger btn-sm" title="Delete" data-toggle="tooltip">
    	<i class="fa fa-trash"></i>
    </button>
</form>