<?php /* C:\xampp\htdocs\agris\resources\views/harvests/harvests.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Harvests</h4>
							<p class="card-category"><i>Count <?php echo e($harvests->count()); ?></i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Harvest No.</th>
                            <th class="text-right">Mass</th>
							<th class="text-right">Quantity</th>
							<th class="text-right">Sold</th>
                            <th class="text-right">Amount</th>
							<th>Date</th>
                            <th>Description</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $harvests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $harvest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($harvest->id); ?></td>
								<td class="text-right"><?php echo e(number_format($harvest->mass)); ?></td>
                                <td class="text-right"><?php echo e(number_format($harvest->quantity)); ?></td>
                                <td class="text-right"><?php echo e(number_format($harvest->sales->sum('quantity'))); ?></td>
                                <td class="text-right"><?php echo e(number_format($harvest->amount)); ?></td>
                                <td><?php echo e(substr($harvest->datetime, 0, 10)); ?></td>
                                <td><?php echo e($harvest->description); ?></td>
								<td class="text-center">
                                    <a href="/harvest/<?php echo e($harvest->id); ?>/sales" class="btn btn-sm btn-info load" title="Edit" data-toggle="tooltip">
                                        <i class="material-icons">show_chart</i>
                                    </a>
                                    <a href="/harvest/<?php echo e($harvest->id); ?>/edit" class="btn btn-sm btn-success edit" title="Edit" data-toggle="tooltip">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="/harvest/<?php echo e($harvest->id); ?>/activate"  class="activate btn btn-sm btn-<?php echo e($harvest->active ? 'warning': 'default'); ?>">
                                        <i class="fa fa-<?php echo e($harvest->active ? 'check': 'ban'); ?>"></i>
                                    </a>
                                    
                                </td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/harvest" class="submit" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Harvest</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<div class="form-group row">
                		<label for="quantity" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Quantity')); ?></label>

                		<div class="col-md-6">
                			<input id="quantity" type="number" class="form-control" name="quantity" required autofocus>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="mass" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Mass (grams)')); ?></label>

                		<div class="col-md-6">
                			<input id="mass" type="number" value="250" class="form-control" name="mass" required>

                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="date" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date')); ?></label>

                        <div class="col-md-6">
                            <input id="date" type="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" name="date" required >

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	<?php echo $__env->make('includes.spinner', ['size' => 15], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </button>
                </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>