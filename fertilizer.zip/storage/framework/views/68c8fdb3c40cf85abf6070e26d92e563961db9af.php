<?php /* C:\xampp\htdocs\LaravelNew\NCPB\resources\views/farmers/farmers.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Farmers</h4>
							<p class="card-category"><i>Count <?php echo e($farmers->count()); ?></i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Farmer No.</th>
							<th>Name</th>
							<th>Phone</th>
							<th>Email</th>
                            <th>National ID</th>
							<th>Location</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($farmer->id); ?></td>
								<td><?php echo e($farmer->name); ?></td>
								<td><a href="tel:<?php echo e($farmer->phone); ?>"><?php echo e($farmer->phone); ?></a></td>
								<td><a href="mailto:<?php echo e($farmer->email); ?>"><?php echo e($farmer->email); ?></a></td>
								<td><?php echo e($farmer->national_id); ?></td>
                                <td><?php echo e($farmer->location); ?></td>
								<td class="text-center">
									<a href="/farmer/<?php echo e($farmer->id); ?>/edit" class="btn btn-sm btn-success edit" title="Edit" data-toggle="tooltip">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="/farmer/<?php echo e($farmer->id); ?>/activate"  class="activate btn btn-sm btn-<?php echo e($farmer->active ? 'warning': 'default'); ?>">
                                        <i class="fa fa-<?php echo e($farmer->active ? 'check': 'ban'); ?>"></i>
                                    </a>
                                    <?php echo $__env->make('includes.delete-button', ['url'=>'/farmer/'.$farmer->id.'/delete'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/farmer" class="submit" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Farmer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<div class="form-group row">
                		<label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                		<div class="col-md-6">
                			<input id="name" type="text" class="form-control" name="name" required autofocus>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>

                		<div class="col-md-6">
                			<input id="email" type="email" class="form-control" name="email">

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone')); ?></label>

                		<div class="col-md-6">
                			<input id="phone" type="tel" class="form-control" name="phone" required>

                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="national_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('National ID')); ?></label>

                        <div class="col-md-6">
                            <input id="national_id" type="text" class="form-control" name="national_id" >

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="location" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Location')); ?></label>

                		<div class="col-md-6">
                			<input id="location" type="text" class="form-control" name="location" >

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	<?php echo $__env->make('includes.spinner', ['size' => 15], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </button>
                </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>