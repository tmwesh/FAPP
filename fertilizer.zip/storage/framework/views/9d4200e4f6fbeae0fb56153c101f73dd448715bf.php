<?php /* /home/admin/web/ncpd.com/public_html/resources/views/products/products.blade.php */ ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Fertilizers</h4>
							<p class="card-category"><i>Count <?php echo e($products->count()); ?></i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Fertilizer No.</th>
							<th>SKU</th>
                            <th>Name</th>
                            <th>Units</th>
							<th>Packaging</th>
							<th>unit</th>
                            <th>Description</th>
							<th>Sold</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($product->id); ?></td>
								<td><?php echo e($product->sku); ?></td>
                                <td><?php echo e($product->name); ?></td>
								<td><?php echo e($product->units); ?></td>
                                <td><?php echo e($product->packaging); ?></td>
                                <td><?php echo e($product->unit_per_packaging); ?></td>
                                <td><?php echo e($product->description); ?></td>
                                <td><?php echo e($product->id); ?></td>
								<td class="text-center">
                                    <a href="/product/<?php echo e($product->id); ?>/sales" class="btn btn-sm btn-info load" title="Edit" data-toggle="tooltip">
                                        <i class="material-icons">show_chart</i>
                                    </a>
									<a href="/product/<?php echo e($product->id); ?>/edit" class="btn btn-sm btn-success edit" title="Edit" data-toggle="tooltip">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="/product/<?php echo e($product->id); ?>/activate"  class="activate btn btn-sm btn-<?php echo e($product->active ? 'warning': 'default'); ?>">
                                        <i class="fa fa-<?php echo e($product->active ? 'check': 'ban'); ?>"></i>
                                    </a>
                                    <?php echo $__env->make('includes.delete-button', ['url'=>'/product/'.$product->id.'/delete'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/product" class="submit" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Fertilizer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label for="sku" class="col-md-4 col-form-label text-md-right"><?php echo e(__('SKU')); ?></label>

                        <div class="col-md-6">
                            <input id="sku" type="text" class="form-control" name="sku" required >

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                		<div class="col-md-6">
                			<input id="name" type="text" class="form-control" name="name" required >

                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Unit of Measure')); ?></label>

                        <div class="col-md-6">
                            <select name="unit_of_measure_id" class="form-control">
                                <option value="1">Mass (Kg)</option>
                                <option value="2">Liters</option>
                            </select>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="packaging" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Packaging')); ?></label>

                        <div class="col-md-6">
                            <input id="packaging" type="text" class="form-control" name="packaging" required>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="unit_per_packaging" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Unit of Package')); ?></label>

                        <div class="col-md-6">
                            <input id="unit_per_packaging" type="text" class="form-control" name="unit_per_packaging" required autofocus>

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	<?php echo $__env->make('includes.spinner', ['size' => 15], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </button>
                </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>