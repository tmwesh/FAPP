<?php /* C:\xampp\htdocs\kwema\resources\views/loans/loans.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Loans</h4>
							<p class="card-category">
                                <i>Count <?php echo e($loans->count()); ?>,</i>
                                <b>Available amount: <?php echo e(number_format($loanable_amount)); ?></b>
                            </p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
                            <a href="#contribution-type-modal" data-toggle="modal" class="btn btn-sm btn-danget"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Loan No.</th>
                            <th>Date</th>
							<th>Member</th>
                            <th class="text-right">Amount</th>
                            <th class="text-right">Amount Payable</th>
                            <th>Due Date</th>
                            <th class="text-center">Paid</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($loan->id); ?></td>
                                <td><?php echo e(substr($loan->date, 0, 10)); ?></td>
								<td><?php echo e($loan->member->name); ?></td>
                                <td class="text-right"><?php echo e(number_format($loan->amount)); ?></td>
                                <td class="text-right"><?php echo e(number_format($loan->amount_payable)); ?></td>
                                <td><?php echo e($loan->due_date); ?></td>
                                <td class="text-center">
                                    
                                </td>
								<td class="text-center">
									
                                    <a href="/loan/<?php echo e($loan->id); ?>/activate"  class="activate btn btn-sm btn-<?php echo e($loan->active ? 'warning': 'default'); ?>">
                                        <i class="fa fa-<?php echo e($loan->active ? 'check': 'ban'); ?>"></i>
                                    </a>
                                    
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/loan" class="submit" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Loan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<div class="form-group row">
                		<label for="member_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Member')); ?></label>

                		<div class="col-md-6">
                			<select name="member_id" id="member_id" class="selectpicker" data-live-search="true" required>
                                <option selected disabled>Select Member</option>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($member->id); ?>"><?php echo e($member->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                            </select>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="amount" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Amount')); ?></label>

                		<div class="col-md-6">
                			<input id="amount" type="number" class="form-control" name="amount" max="<?php echo e($loanable_amount + 3000000); ?>" required>

                		</div>
                	</div>

                    <div class="form-group row">
                        <label for="date" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date')); ?></label>

                        <div class="col-md-6">
                            <input id="date" type="date" class="form-control" name="date" required>

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	<?php echo $__env->make('includes.spinner', ['size' => 15], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </button>
                </div>

        </form>
    </div>
</div>
<div class="modal fade" id="contribution-type-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/loanable" class="submit" >
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Loan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="form-group row">
                        <div class="col-md-6">
                            <?php $__currentLoopData = $contribution_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" name="types[]" type="checkbox" value="<?php echo e($type->id); ?>" <?php echo e($type->loanable ? 'checked': ''); ?>>
                                        <span class="form-check-sign">
                                            <span class="check"></span>
                                        </span>
                                        <?php echo e($type->title); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                        Save changes
                        <?php echo $__env->make('includes.spinner', ['size' => 15], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </button>
                </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>