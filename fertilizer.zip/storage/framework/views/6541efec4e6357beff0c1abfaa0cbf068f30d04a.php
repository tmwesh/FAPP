<?php /* C:\xampp\htdocs\agris\resources\views/includes/sidebar.blade.php */ ?>
<div class="sidebar" data-color="orange" data-background-color="white" data-image="/images/logo.png">
<!--
Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

Tip 2: you can also add an image using data-image tag
-->
<div class="logo">
    <a href="/" class="simple-text logo-normal">
        <img src="/images/logo.png" alt="Agris Logo" height="40" class="pr-4">
        <?php echo e(config('app.name', 'Laravel')); ?>

    </a>
</div>
<div class="sidebar-wrapper">
    <ul class="nav">
        <li class="nav-item <?php echo e(Request::is('dashboard') ? 'active': ''); ?>">
            <a class="nav-link" href="/dashboard">
                <i class="material-icons">dashboard</i>
                <p>Dashboard</p>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('customers') ? 'active': ''); ?>">
            <a class="nav-link" href="/customers">
                <i class="material-icons">person</i>
                <p>Customers</p>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('harvests') ? 'active': ''); ?>">
            <a class="nav-link" href="/harvests">
                <i class="material-icons">person</i>
                <p>Harvest</p>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('credits') ? 'active': ''); ?>">
            <a class="nav-link" href="/credits">
                <i class="material-icons">person</i>
                <p>Credit</p>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('expenses') ? 'active': ''); ?>">
            <a class="nav-link" href="/expenses">
                <i class="material-icons">person</i>
                <p>Expenses</p>
            </a>
        </li>

        <li class="nav-item <?php echo e(Request::is('settings') ? 'active': ''); ?>">
            <a class="nav-link" href="/settings">
                <i class="material-icons">settings</i>
                <p>Settings</p>
            </a>
        </li>

    </ul>
</div>

</div>