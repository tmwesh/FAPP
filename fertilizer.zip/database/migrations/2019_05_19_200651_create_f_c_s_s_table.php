<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFCSSTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('f_c_s_s', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->string('phone');
            $table->string('email');
            $table->string('location');
            $table->string('bond_id');
            $table->string('compliance_no');
            $table->timestamps();
            $table->softDeletes();
           // $table->userstamps();

            $table->foreign('bond_id')->references('bond_id')->on('bonds');
            $table->foreign('compliance_no')->references('compliance_no')->on('pins');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('f_c_s_s');
    }
}
