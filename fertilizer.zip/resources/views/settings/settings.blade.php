@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
                <div class="card-header card-header-warning card-header-icon">
                    <a href="#sms-template-modal" data-toggle="modal" class="btn btn-success">SMS Template</a>
                </div>
                <div class="card-footer">
                    <div class="stats">
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
                <div class="card-header card-header-success card-header-icon">
                    
                </div>
                <div class="card-footer">
                    <div class="stats">
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
                <div class="card-header card-header-danger card-header-icon">
                    
                </div>
                <div class="card-footer">
                    <div class="stats">
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                    
                </div>
                <div class="card-footer">
                    <div class="stats">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
<div class="modal fade" id="sms-template-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/settings/sms-template" class="submit" >
            @csrf
            <input type="hidden" name="id" >
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">SMS Template</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="form-group row">
                        <label for="sms_template" class="col-md-4 col-form-label text-md-right">{{ __('SMS Template') }}</label>

                        <div class="col-md-6">
                            <textarea id="sms_template" class="form-control" style="min-height:300px;" name="sms_template" required autofocus>{{ $sms_template }}</textarea>

                        </div>
                    </div>
                    

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                        Save changes
                        @include('includes.spinner', ['size' => 15])
                    </button>
                </div>

        </form>
    </div>
</div>

@endsection