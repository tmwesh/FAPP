@extends('layouts.app')

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Fertilizers</h4>
							<p class="card-category"><i>Count {{ $products->count() }}</i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Fertilizer No.</th>
							<th>SKU</th>
                            <th>Name</th>
                            <th>Units</th>
							<th>Packaging</th>
							<th>unit</th>
                            <th>Description</th>
							<th>Sold</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							@foreach($products as $key => $product)
							<tr>
								<td>{{ $product->id }}</td>
								<td>{{ $product->sku }}</td>
                                <td>{{ $product->name }}</td>
								<td>{{ $product->units }}</td>
                                <td>{{ $product->packaging }}</td>
                                <td>{{ $product->unit_per_packaging }}</td>
                                <td>{{ $product->description }}</td>
                                <td>{{ $product->id }}</td>
								<td class="text-center">
                                    <a href="/product/{{$product->id}}/sales" class="btn btn-sm btn-info load" title="Edit" data-toggle="tooltip">
                                        <i class="material-icons">show_chart</i>
                                    </a>
									<a href="/product/{{$product->id}}/edit" class="btn btn-sm btn-success edit" title="Edit" data-toggle="tooltip">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="/product/{{$product->id}}/activate"  class="activate btn btn-sm btn-{{ $product->active ? 'warning': 'default'}}">
                                        <i class="fa fa-{{ $product->active ? 'check': 'ban'}}"></i>
                                    </a>
                                    @include('includes.delete-button', ['url'=>'/product/'.$product->id.'/delete'])
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/product" class="submit" >
            @csrf
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Fertilizer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label for="sku" class="col-md-4 col-form-label text-md-right">{{ __('SKU') }}</label>

                        <div class="col-md-6">
                            <input id="sku" type="text" class="form-control" name="sku" required >

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                		<div class="col-md-6">
                			<input id="name" type="text" class="form-control" name="name" required >

                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Unit of Measure') }}</label>

                        <div class="col-md-6">
                            <select name="unit_of_measure_id" class="form-control">
                                <option value="1">Mass (Kg)</option>
                                <option value="2">Liters</option>
                            </select>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="packaging" class="col-md-4 col-form-label text-md-right">{{ __('Packaging') }}</label>

                        <div class="col-md-6">
                            <input id="packaging" type="text" class="form-control" name="packaging" required>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="unit_per_packaging" class="col-md-4 col-form-label text-md-right">{{ __('Unit of Package') }}</label>

                        <div class="col-md-6">
                            <input id="unit_per_packaging" type="text" class="form-control" name="unit_per_packaging" required autofocus>

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right">{{ __('Description') }}</label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	@include('includes.spinner', ['size' => 15])
                    </button>
                </div>

        </form>
    </div>
</div>
@endsection
