@extends('layouts.app')

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Credits</h4>
							<p class="card-category"><i>Count {{ $credits->count() }}</i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Credit No.</th>
                            <th>Customer</th>
							<th class="text-right">Amount</th>
							<th>Date</th>
                            <th>Description</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							@foreach($credits as $key => $credit)
							<tr>
								<td>{{ $credit->id }}</td>
                                <td>{{ $credit->customer->name }}</td>
                                <td class="text-right">{{ number_format($credit->amount) }}</td>
                                <td>{{ substr($credit->datetime, 0, 10) }}</td>
                                <td>{{ $credit->description }}</td>
								<td class="text-center">
                                    <a href="/credit/{{$credit->id}}/activate"  class="activate btn btn-sm btn-{{ $credit->active ? 'warning': 'default'}}">
                                        <i class="fa fa-{{ $credit->active ? 'check': 'ban'}}"></i>
                                    </a>
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/credit" class="submit" >
            @csrf
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Credit</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<div class="form-group row">
                        <label for="customer_id" class="col-md-4 col-form-label text-md-right">{{ __('Customer') }}</label>

                        <div class="col-md-6">
                            <select name="customer_id" id="customer_id" class="selectpicker" data-live-search="true" required>
                                <option selected disabled value="">Select Customer</option>
                                @foreach($customers as $key => $customer)
                                <option value="{{$customer->id}}">{{ $customer->name }}</option>
                                @endforeach         
                            </select>
                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="amount" class="col-md-4 col-form-label text-md-right">{{ __('Amount') }}</label>

                		<div class="col-md-6">
                			<input id="amount" type="number" class="form-control" name="amount" required>

                		</div>
                	</div>

                    <div class="form-group row">
                        <label for="date" class="col-md-4 col-form-label text-md-right">{{ __('Date') }}</label>

                        <div class="col-md-6">
                            <input id="date" type="date" class="form-control" name="date" >

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right">{{ __('Description') }}</label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	@include('includes.spinner', ['size' => 15])
                    </button>
                </div>

        </form>
    </div>
</div>
@endsection
