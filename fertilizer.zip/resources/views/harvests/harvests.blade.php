@extends('layouts.app')

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Harvests</h4>
							<p class="card-category"><i>Count {{ $harvests->count() }}</i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Harvest No.</th>
                            <th class="text-right">Mass</th>
							<th class="text-right">Quantity</th>
							<th class="text-right">Sold</th>
                            <th class="text-right">Amount</th>
							<th>Date</th>
                            <th>Description</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							@foreach($harvests as $key => $harvest)
							<tr>
								<td>{{ $harvest->id }}</td>
								<td class="text-right">{{ number_format($harvest->mass) }}</td>
                                <td class="text-right">{{ number_format($harvest->quantity) }}</td>
                                <td class="text-right">{{ number_format($harvest->sales->sum('quantity')) }}</td>
                                <td class="text-right">{{ number_format($harvest->amount) }}</td>
                                <td>{{ substr($harvest->datetime, 0, 10) }}</td>
                                <td>{{ $harvest->description }}</td>
								<td class="text-center">
                                    <a href="/harvest/{{$harvest->id}}/sales" class="btn btn-sm btn-info load" title="Edit" data-toggle="tooltip">
                                        <i class="material-icons">show_chart</i>
                                    </a>
                                    <a href="/harvest/{{$harvest->id}}/edit" class="btn btn-sm btn-success edit" title="Edit" data-toggle="tooltip">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="/harvest/{{$harvest->id}}/activate"  class="activate btn btn-sm btn-{{ $harvest->active ? 'warning': 'default'}}">
                                        <i class="fa fa-{{ $harvest->active ? 'check': 'ban'}}"></i>
                                    </a>
                                    {{-- @include('includes.delete-button', ['url'=>'/harvest/'.$harvest->id.'/delete']) --}}
                                </td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/harvest" class="submit" >
            @csrf
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Harvest</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<div class="form-group row">
                		<label for="quantity" class="col-md-4 col-form-label text-md-right">{{ __('Quantity') }}</label>

                		<div class="col-md-6">
                			<input id="quantity" type="number" class="form-control" name="quantity" required autofocus>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="mass" class="col-md-4 col-form-label text-md-right">{{ __('Mass (grams)') }}</label>

                		<div class="col-md-6">
                			<input id="mass" type="number" value="250" class="form-control" name="mass" required>

                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="date" class="col-md-4 col-form-label text-md-right">{{ __('Date') }}</label>

                        <div class="col-md-6">
                            <input id="date" type="date" class="form-control" value="{{ date('Y-m-d') }}" name="date" required >

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right">{{ __('Description') }}</label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	@include('includes.spinner', ['size' => 15])
                    </button>
                </div>

        </form>
    </div>
</div>
@endsection
