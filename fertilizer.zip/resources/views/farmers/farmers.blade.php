@extends('layouts.app')

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Farmers</h4>
							<p class="card-category"><i>Count {{ $farmers->count() }}</i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Farmer No.</th>
							<th>Name</th>
							<th>Phone</th>
							<th>Email</th>
                            <th>National ID</th>
							<th>Location</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							@foreach($farmers as $key => $farmer)
							<tr>
								<td>{{ $farmer->id }}</td>
								<td>{{ $farmer->name }}</td>
								<td><a href="tel:{{ $farmer->phone }}">{{ $farmer->phone }}</a></td>
								<td><a href="mailto:{{ $farmer->email }}">{{ $farmer->email }}</a></td>
								<td>{{ $farmer->national_id }}</td>
                                <td>{{ $farmer->location }}</td>
								<td class="text-center">
									<a href="/farmer/{{$farmer->id}}/edit" class="btn btn-sm btn-success edit" title="Edit" data-toggle="tooltip">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="/farmer/{{$farmer->id}}/activate"  class="activate btn btn-sm btn-{{ $farmer->active ? 'warning': 'default'}}">
                                        <i class="fa fa-{{ $farmer->active ? 'check': 'ban'}}"></i>
                                    </a>
                                    @include('includes.delete-button', ['url'=>'/farmer/'.$farmer->id.'/delete'])
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/farmer" class="submit" >
            @csrf
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Farmer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<div class="form-group row">
                		<label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                		<div class="col-md-6">
                			<input id="name" type="text" class="form-control" name="name" required autofocus>

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="email" class="col-md-4 col-form-label text-md-right">{{ __('Email') }}</label>

                		<div class="col-md-6">
                			<input id="email" type="email" class="form-control" name="email">

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="phone" class="col-md-4 col-form-label text-md-right">{{ __('Phone') }}</label>

                		<div class="col-md-6">
                			<input id="phone" type="tel" class="form-control" name="phone" required>

                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="national_id" class="col-md-4 col-form-label text-md-right">{{ __('National ID') }}</label>

                        <div class="col-md-6">
                            <input id="national_id" type="text" class="form-control" name="national_id" >

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="location" class="col-md-4 col-form-label text-md-right">{{ __('Location') }}</label>

                		<div class="col-md-6">
                			<input id="location" type="text" class="form-control" name="location" >

                		</div>
                	</div>
                	<div class="form-group row">
                		<label for="description" class="col-md-4 col-form-label text-md-right">{{ __('Description') }}</label>

                		<div class="col-md-6">
                			<textarea id="description" class="form-control" name="description"></textarea>

                		</div>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	@include('includes.spinner', ['size' => 15])
                    </button>
                </div>

        </form>
    </div>
</div>
@endsection
