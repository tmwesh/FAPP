<div class="sidebar" data-color="danger" data-background-color="white" data-image="/images/logo.png">
<!--
Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

Tip 2: you can also add an image using data-image tag
-->
<div class="logo">
    <a href="/" class="simple-text logo-normal">
        <img src="/images/logo.png" alt="Agris Logo" height="40" class="pr-4">
        {{ config('app.name', 'Laravel') }}
    </a>
</div>
<div class="sidebar-wrapper">
    <ul class="nav">
        <li class="nav-item {{ Request::is('dashboard') ? 'active': ''}}">
            <a class="nav-link" href="/dashboard">
                <i class="material-icons">dashboard</i>
                <p>Dashboard</p>
            </a>
        </li>
        <li class="nav-item {{ Request::is('products') ? 'active': ''}}">
            <a class="nav-link" href="/products">
                <i class="material-icons">person</i>
                <p>Fertilizers</p>
            </a>
        </li>
        <li class="nav-item {{ Request::is('fcs') ? 'active': ''}}">
            <a class="nav-link" href="/FCS/FCS">
                <i class="material-icons">person</i>
                <p>FCS</p>
            </a>
        </li>
        <li class="nav-item {{ Request::is('farmers') ? 'active': ''}}">
            <a class="nav-link" href="/farmers">
                <i class="material-icons">person</i>
                <p>Farmers</p>
            </a>
        </li>
        <li class="nav-item {{ Request::is('buyers') ? 'active': ''}}">
            <a class="nav-link" href="/buyers">
                <i class="material-icons">person</i>
                <p>Buyers</p>
            </a>
        </li>
        <li class="nav-item {{ Request::is('credits') ? 'active': ''}}">
            <a class="nav-link" href="/credits">
                <i class="material-icons">person</i>
                <p>Credit</p>
            </a>
        </li>
        <li class="nav-item {{ Request::is('expenses') ? 'active': ''}}">
            <a class="nav-link" href="/expenses">
                <i class="material-icons">person</i>
                <p>Expenses</p>
            </a>
        </li>

        <li class="nav-item {{ Request::is('settings') ? 'active': ''}}">
            <a class="nav-link" href="/settings">
                <i class="material-icons">settings</i>
                <p>Settings</p>
            </a>
        </li>

    </ul>
</div>

</div>