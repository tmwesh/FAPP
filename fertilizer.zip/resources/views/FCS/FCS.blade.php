@extends('layouts.app')

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header card-header-info">
					<div class="row">
						<div class="col-sm-10">
							<h4 class="card-title">Farmers Corporative Society</h4>
							<p class="card-category"><i>Count {{ $FCSS->count() }}</i></p>
							
						</div>
						<div class="col-sm-2">
							<a href="#form-modal" data-toggle="modal" class="btn btn-sm btn-success"><i class="material-icons">add</i></a>
						</div>

					</div>

				</div>
				<div class="card-body table-responsive">
					<table class="table table-hover">
						<thead class="text-info">
							<th>Reg No.</th>
							<th>Location</th>
                            <th>Name</th>
                            <th>Bond</th>
							<th>Compliance</th>
							<th>email</th>
                            <th>Phone</th>
							<th>Sold</th>
							<th class="text-center">Action</th>
						</thead>
						<tbody>
							@foreach($FCSS as $key => $FCSS)
							<tr>
								<td>{{ $FCSS->id }}</td>
								<td>{{ $FCSS->location }}</td>
                                <td>{{ $FCSS->name }}</td>
								<td>{{ $FCSS->bond_id }}</td>
                                <td>{{ $FCSS->compliance_no }}</td>
                                <td>{{ $FCSS->email }}</td>
                                <td>{{ $FCSS->phone }}</td>
                                <td>{{ $FCSS->id }}</td>
								<td class="text-center">
                                    <a href="/product/{{$product->id}}/sales" class="btn btn-sm btn-info load" title="Edit" data-toggle="tooltip">
                                        <i class="material-icons">show_chart</i>
                                    </a>
									<a href="/product/{{$product->id}}/edit" class="btn btn-sm btn-success edit" title="Edit" data-toggle="tooltip">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="/product/{{$product->id}}/activate"  class="activate btn btn-sm btn-{{ $product->active ? 'warning': 'default'}}">
                                        <i class="fa fa-{{ $product->active ? 'check': 'ban'}}"></i>
                                    </a>
                                    @include('includes.delete-button', ['url'=>'/product/'.$product->id.'/delete'])
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="form-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="post" action="/FCS/FCS" class="submit" >
            @csrf
            <input type="hidden" name="id" >
        	<div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add FCS</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label for="phone" class="col-md-4 col-form-label text-md-right">{{ __('phone') }}</label>

                        <div class="col-md-6">
                            <input id="phone" type="text" class="form-control" name="phone" required >

                        </div>
                    </div>
                	<div class="form-group row">
                		<label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                		<div class="col-md-6">
                			<input id="name" type="text" class="form-control" name="name" required >

                		</div>
                	</div>
                    <div class="form-group row">
                        <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('bond_id') }}</label>

                        <div class="col-md-6">
                            <select name="bond_id" class="form-control">
                                <option value="1">Mass (Kg)</option>
                                <option value="2">Liters</option>
                            </select>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="compliance_no" class="col-md-4 col-form-label text-md-right">{{ __('compliance_no') }}</label>

                        <div class="col-md-6">
                            <input id="compliance_no" type="text" class="form-control" name="compliance_no" required>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('email') }}</label>

                        <div class="col-md-6">
                            <input id="email" type="text" class="form-control" name="email" required autofocus>

                        </div>
                    </div>
                	

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                    	Save changes
                    	@include('includes.spinner', ['size' => 15])
                    </button>
                </div>

        </form>
    </div>
</div>
@endsection
