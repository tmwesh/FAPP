
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

// window.Vue = require('vue');

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i);
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default));

// Vue.component('example-component', require('./components/ExampleComponent.vue').default);

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

// const app = new Vue({
//     el: '#app'
// });


var mobile_menu_visible = 0,
    mobile_menu_initialized = false,
    toggle_initialized = false,
    bootstrap_nav_initialized = false,
    $sidebar,
    $sidebar_nav,
    $nav_content,
    $toggle,
    isWindows,
    $navbar,
    nav_content,
    mobile_menu_content,
    content_buff,
    $navbar_form,
    main_panel_height,
    $layer,
    $sidebar_wrapper;

var Agris = {

	$container: $('#app'),
	$body: $('body'),
	$mainPanel: $('.main-panel'),
	$inContent: $('div#in-content'),
	$loader: $('#loader'),

	$menu_section: $('.sidebar-wrapper ul.nav'),

	$messageBox: $('#message-box'),


	init() {
		console.log('kwema', this.$container)

		this.loadInit()


		// load menu items listner
	    this.$menu_section.on('click','li a', this.loadMenuContent);

	    $( document ).ajaxError(( event, request ) => {
            console.log(request)
            if (request.status === 401){
                this.alertBox(request.statusText + '. Please login again.')
                window.location.href = '/login';
            }
        });
	},


	loadInit() {
		this.setModals()

		$('button svg.spinner').hide();

		$('.selectpicker').selectpicker();

		this.loadDashboardCharts();

	},



	alertBox(message, status = 'danger') {

		let messageBoxType = status;

		let alert = `
				<div class="alert alert-${messageBoxType}" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
	                ${message}
	            </div>
			`

		this.$messageBox.html(alert)

		this.$messageBox.slideDown()
	},


	loadContent (toLoad) {
		console.log(toLoad)
		this.$loader.fadeIn(100);
		this.$messageBox.hide();
        $('div#in-content').load(toLoad,'',this.showNewContent);
        try {
		    // history push
		    history.pushState(null, null, toLoad.split(' ')[0]);
	    	
	    } catch(e) {
	    	console.log(e);
	    	window.location.hash = toLoad.split(' ')[0];
	    }
    },

    showNewContent (res, status, xhr) {
    	console.log( 'xhr', xhr)
    	console.log('showing content')
		
    	var $mainPanel = $(this)

    	if(status == 'error') {
    		var message = xhr.status + ': ' +xhr.statusText;

    		if(!res) {
    			message += ', Check your internet connection.'
    		}
    		Agris.alertBox(message, 'danger');
    		$mainPanel.html(res);
    	}
        $('div#in-content').show(0, Agris.hideLoader());
        Agris.loadInit()

    },

    hideLoader () {
    	console.log('hiddi content')
        Agris.$loader.fadeOut(100);
    },



    loadMenuContent(e) {
		console.log(e)
		console.log(this)
		var $this = $(this);

		if($this.is('[data-toggle="collapse"]')){
			return;
		}

		var activeLi = Agris.$menu_section.find('li')

		activeLi.removeClass('active')
		
	    var li = $this.closest('li').addClass('active');
	    // check if its a collpase menu, make the menu link active also
	    if(li.closest('div.collapse').hasClass('collapse')){ // the div
	    	// remove the other collapsed
	    	activeLi.find('div.collapse.in').removeClass('in')

	    	li.closest('div.collapse').addClass('in').closest('li').addClass('active');
	    }
	    
	    var toLoad = $this.attr('href')+' .main-panel > div#in-content > #in';

	    // todo: animate the hidding
	    $('div#in-content').hide(0,Agris.loadContent(toLoad));
	    
	    
	    return false;
		
	},


	swapClass (elem,from,to){
    	elem.removeClass(from).addClass(to);
    },

    populateForm (form,data){
    	$.each(data,function(k,v){

			let toFind = ''

			if (typeof v == 'object') {
				toFind = '[name="'+k+'[]"]'
				form.find(toFind).each(function(i, val) {

					val.checked = (v[val.value]  || false)
				})
			}

			toFind = '[name="'+k+'"]'


			var $element = form.find(toFind)
			// console.log('$element', $element.attr('type'))
			// load image to a holder
			if($element.attr('type') == 'file') {
				$('img#'+k+'_holder').attr('src', v);
			} else {
				$element.val(v);
			}
		});

    },

    setModals() {
	    // We put modals out of wrapper to working properly

	    // first we remove modals direct parent to body 
	    $('body > .modal').remove();
	    // then add the new
	    $('.modal').appendTo("body");
		
	},


	loadDashboardCharts() {
		if ($('#monthly-contributions-chart').length != 0 || $('#completedTasksChart').length != 0 || $('#websiteViewsChart').length != 0) {
            /* ----------==========     Daily Sales Chart initialization    ==========---------- */

            var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
			var config = {
				type: 'line',
				data: {
					labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
					datasets: [{
						label: 'My First dataset',
						backgroundColor: 'red',
						borderColor: 'pink',
						data: [
							4,
							9,
							19,
							35,
							28,
							14,
							52
						],
						fill: false,
					}]
				},
				options: {
					responsive: true,
					title: {
						display: true,
						text: 'Chart.js Line Chart'
					},
					tooltips: {
						mode: 'index',
						intersect: false,
					},
					hover: {
						mode: 'nearest',
						intersect: true
					},
					scales: {
						xAxes: [{
							display: true,
							scaleLabel: {
								display: true,
								labelString: 'Month'
							}
						}],
						yAxes: [{
							display: true,
							scaleLabel: {
								display: true,
								labelString: 'Value'
							}
						}]
					}
				}
			};

			var ctx = document.getElementById('monthly-contributions-chart').getContext('2d');
			window.myLine = new Chart(ctx, config);


			var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		var color = Chart.helpers.color;
		var barChartData = {
			labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
			datasets: [{
				label: 'Loans',
				backgroundColor: color('blue').alpha(0.5).rgbString(),
				borderColor: 'blue',
				borderWidth: 1,
				data: [
					60,
					54,
					49,
					44,
					34,
					40,
					10
				]
			}, {
				label: 'Contributions',
				backgroundColor: color('green').alpha(0.5).rgbString(),
				borderColor: 'green',
				borderWidth: 1,
				data: [
					20,
					30,
					35,
					29,
					41,
					49,
					65
				]
			}]

		};

		window.onload = function() {
			var ctx = document.getElementById('websiteViewsChart').getContext('2d');
			window.myBar = new Chart(ctx, {
				type: 'bar',
				data: barChartData,
				options: {
					responsive: true,
					legend: {
						position: 'top',
					},
					title: {
						display: true,
						text: 'Loan vs Contributions'
					}
				}
			});

		};
		
        }
	},



	$menu_section: $('.sidebar-wrapper ul.nav'),

    misc:{
        navbar_menu_visible: 0,
        active_collapse: true,
        disabled_collapse_init: 0

    },
    initSidebarsCheck: function(){
        // Init navigation toggle for small screens
        if($(window).width() <= 991){
            if($sidebar.length != 0){
                Agris.initSidebarMenu();
            } else {
                Agris.initBootstrapNavbarMenu();
            }
        } else if(mobile_menu_initialized == true){
            // reset all the additions that we made for the sidebar wrapper only if the screen is bigger than 991px
            $sidebar_wrapper.find('.navbar-form').remove();
            $sidebar_wrapper.find('.nav-mobile-menu').remove();

            mobile_menu_initialized = false;
        }
    },

    initMinimizeSidebar: function(){
        $('#minimizeSidebar').click(function(){
            var $btn = $(this);

            if(Agris.misc.sidebar_mini_active == true){
                $('body').removeClass('sidebar-mini');
                $btn.html('<i class="ti-more-alt"></i>');
                Agris.misc.sidebar_mini_active = false;

            }else{
                $('body').addClass('sidebar-mini');
                $btn.html('<i class="ti-menu-alt"></i>');
                Agris.misc.sidebar_mini_active = true;
            }

            // we simulate the window Resize so the charts will get updated in realtime.
            // var simulateWindowResize = setInterval(function(){
            //     window.dispatchEvent(new Event('resize'));
            // },180);

            // // we stop the simulation of Window Resize after the animations are completed
            // setTimeout(function(){
            //     clearInterval(simulateWindowResize);
            // },1000);
        });
    },



    initSidebarMenu: function(){
        $sidebar_wrapper = $('.sidebar-wrapper');

        if(!mobile_menu_initialized){

            $navbar = $('nav').find('.navbar-collapse').first().clone(true);

            nav_content = '';
            mobile_menu_content = '';

            $navbar.children('ul').each(function(){

                content_buff = $(this).html();
                nav_content = nav_content + content_buff;
            });

            nav_content = '<ul class="nav nav-mobile-menu">' + nav_content + '</ul>';

            $navbar_form = $('nav').find('.navbar-form').clone(true);

            $sidebar_nav = $sidebar_wrapper.find(' > .nav');

            // insert the navbar form before the sidebar list
            $nav_content = $(nav_content);
            $nav_content.insertBefore($sidebar_nav);
            $navbar_form.insertBefore($nav_content);

            $(".sidebar-wrapper .dropdown .dropdown-menu > li > a").click(function(event) {
                event.stopPropagation();

            });

            mobile_menu_initialized = true;
        } else {
            if($(window).width() > 991){
                // reset all the additions that we made for the sidebar wrapper only if the screen is bigger than 991px
                $sidebar_wrapper.find('.navbar-form').remove();
                $sidebar_wrapper.find('.nav-mobile-menu').remove();

                mobile_menu_initialized = false;
            }
        }

        if(!toggle_initialized){
            $toggle = $('.navbar-toggler');

            $toggle.click(function (){
            	console.log('toggle')

                if(mobile_menu_visible == 1) {
                    $('html').removeClass('nav-open');

                    $('.close-layer').remove();
                    setTimeout(function(){
                        $toggle.removeClass('toggled');
                    }, 400);

                    mobile_menu_visible = 0;
                } else {
                    setTimeout(function(){
                        $toggle.addClass('toggled');
                    }, 430);

                    main_panel_height = $('.main-panel')[0].scrollHeight;
                    $layer = $('<div class="close-layer"></div>');
                    $layer.css('height',main_panel_height + 'px');
                    $layer.appendTo(".main-panel");


                    setTimeout(function(){
                        $layer.addClass('visible');
                    }, 100);

                    $layer.click(function() {
                        $('html').removeClass('nav-open');
                        mobile_menu_visible = 0;

                        $layer.removeClass('visible');

                         setTimeout(function(){
                            $layer.remove();
                            $toggle.removeClass('toggled');

                         }, 400);
                    });

                    $('html').addClass('nav-open');
                    mobile_menu_visible = 1;

                }
            });

            toggle_initialized = true;
        }

    },

    initBootstrapNavbarMenu: debounce(function(){

        if(!bootstrap_nav_initialized){
            $navbar = $('nav').find('.navbar-collapse').first().clone(true);

            nav_content = '';
            mobile_menu_content = '';

            //add the content from the regular header to the mobile menu
            $navbar.children('ul').each(function(){
                content_buff = $(this).html();
                nav_content = nav_content + content_buff;
            });

            nav_content = '<ul class="nav nav-mobile-menu">' + nav_content + '</ul>';

            $navbar.html(nav_content);
            $navbar.addClass('off-canvas-sidebar');

            // append it to the body, so it will come from the right side of the screen
            $('body').append($navbar);

            $toggle = $('.navbar-toggler');

            $navbar.find('a').removeClass('btn btn-round btn-default');
            $navbar.find('button').removeClass('btn-round btn-fill btn-info btn-primary btn-success btn-danger btn-warning btn-neutral');
            $navbar.find('button').addClass('btn-simple btn-block');

            $toggle.click(function (){
                if(mobile_menu_visible == 1) {
                    $('html').removeClass('nav-open');

                    $('.close-layer').remove();
                    setTimeout(function(){
                        $toggle.removeClass('toggled');
                    }, 400);

                    mobile_menu_visible = 0;
                } else {
                    setTimeout(function(){
                        $toggle.addClass('toggled');
                    }, 430);

                    $layer = $('<div class="close-layer"></div>');
                    $layer.appendTo(".wrapper-full-page");

                    setTimeout(function(){
                        $layer.addClass('visible');
                    }, 100);


                    $layer.click(function() {
                        $('html').removeClass('nav-open');
                        mobile_menu_visible = 0;

                        $layer.removeClass('visible');

                         setTimeout(function(){
                            $layer.remove();
                            $toggle.removeClass('toggled');

                         }, 400);
                    });

                    $('html').addClass('nav-open');
                    mobile_menu_visible = 1;

                }

            });
            bootstrap_nav_initialized = true;
        }
    }, 500),
}



function debounce(func, wait, immediate) {
	var timeout;
	return function() {
		var context = this, args = arguments;
		clearTimeout(timeout);
		timeout = setTimeout(function() {
			timeout = null;
			if (!immediate) func.apply(context, args);
		}, wait);
		if (immediate && !timeout) func.apply(context, args);
	};
};

// activate collapse right menu when the windows is resized
$(window).resize(function(){
    Agris.initSidebarsCheck();

});



$(function() {

	Agris.init();

	
	$sidebar = $('.sidebar');

	if($('body').hasClass('sidebar-mini')){
        Agris.misc.sidebar_mini_active = true;
    }

    Agris.initSidebarsCheck();
    Agris.initMinimizeSidebar();


    // listen to when the user press the back or forward button
    window.onpopstate = function(event) {
		console.log("location: " + document.location );
		var toLoad = document.location+' .main-panel > div#in-content > #in'

    	Agris.$loader.fadeIn(100);
    	$('div#in-content').hide().load(toLoad,'',Agris.showNewContent);
	};


    Agris.$body.on('click','a.load',function(e){
		e.preventDefault();

		var $this = $(this),
			href = $this.attr('href'),
			toLoad = href+' .main-panel > div#in-content > #in';

    	$('div#in-content').hide(0,Agris.loadContent(toLoad));


		// window.location.hash = href;

		// loadContent(toLoad);
	});


	Agris.$body.on('submit', 'form.submit', function(e) {
		e.preventDefault();
		// collect data
		let form = $(this),
			data = form.serialize(),
			url = form.attr('action'),
			method = (form.attr('method') || 'get').toLowerCase(),
			btn = form.find('button[type="submit"]');

		// post data

		Agris.$messageBox.slideUp(100)

		let spinner = btn.find('svg.spinner')

		spinner.show()
		btn.prop('disabled', true)


		
		form.ajaxSubmit({
			// beforeSubmit(arr, $form, options) {
			// 	console.log(arr)
			// 	return false;
			// },
			success: function(res, status, jhr) {
				// console.log(res, status, jhr)
				// console.log(window)
				// console.log(jhr.getResponseHeader("Content-type"))
				// console.log(jhr.getAllResponseHeaders())

				// stop loading
				spinner.hide()
				btn.prop('disabled', false)


				if( jhr.getResponseHeader("Content-type").indexOf('text/html') != -1) {
					console.log('is HTML')
					Agris.showContent(res, status, jhr)
				}
				// toast response
				if(res.message) {
					Agris.alertBox(res.message, res.status ? 'success': 'danger')
				}

				


				// if has modal, close modal
				if(res.status && res.status == 1) {
					form.closest('[role="dialog"]').modal('hide')
					form[0].reset()

					// todo
					// load only the middle part remove reload
					// location.reload()
					var toLoad = location.href
					if(res.url) {
						toLoad = res.url
					}
					
					toLoad += ' .main-panel > div#in-content > #in';

	    			$('div#in-content').hide(0,Agris.loadContent(toLoad));
					// conte
					
				}


				// 
			},
			uploadProgress(e,position,total,percentage) {
				btn.text('loading... '+percentage+'%')
			},
			error: function(error, text, erorrThrown) {
				// stop loading
				spinner.hide()
				btn.prop('disabled', false)

				let html = `<p>${error.statusText}</p>`

				if(error.status == 422) {
	                html = '<ul>'
	                Object.keys(error.responseJSON.errors).map(function(k, v) {
	                    // console.log(error.response.data[k]);
	                    html += '<li>' + error.responseJSON.errors[k] + '</li>'
	                })
	                html += '</ul>'
	            }
				Agris.alertBox(html, 'warning')

			}
		})

	})



	Agris.$body.on('click','a.edit',function(e){
        e.preventDefault();

        console.log('editing')

        var $this = $(this),
        	url = $this.attr('href'),
        	l = $this.find('i'),
        	modal = $('#form-modal'),
        	form = modal.find('form');

		Agris.swapClass(l,'fa-edit','fa-spin fa-spinner');
		Agris.$messageBox.slideUp(100)
        $.get(url,'',function(response){
        	var res = response;
			
			// populate form
			Agris.populateForm(form,res);

			modal.modal('show');


        }).always(function(){
			Agris.swapClass(l,'fa-spin fa-spinner','fa-edit');
        }).fail(function(error,text,errorThrown){
        	let html = `<p>${error.statusText}</p>`
        	Agris.alertBox(html, 'warning')
        });

        let token = document.head.querySelector('meta[name="csrf-token"]');

		var dropzoneOptions = {
				url: `/api/video`,
				paramName: 'video',
				// maxFilesize: 8, // MB
		        addRemoveLinks: true,
		        chunking: true,
		        chunkSize: 500000, // .5 MB
		        forceChunking: true,
		        parallelChunkUploads: true,
		        retryChunks: true,
		        retryChunksLimit: 3,
		        acceptedFiles: 'video/*,.mkv',
		        dictDefaultMessage: 'Drop videos here or Click to select videos from file.<br><b>Mobile friendly.</b><br>8 MB max',
		        headers: {
		            'X-CSRF-TOKEN': token.content,
		            'accept': 'application/json'
		        }
			};

		// console.log($('form.dropzone'))
		console.log(modal.find('.dropzone'))
		if(modal.find('.dropzone').length){

			let myDropzone = new Dropzone(modal.find('.dropzone')[0], dropzoneOptions);
		}



		// console.log(myDropzone)

		// myDropzone.on("success", (file, response, data) => {
//              console.log('file', file)
//              console.log('response', response)
//              console.log('data', data)
//          });

    });


    Agris.$body.on('click','a.activate',function(e){
        e.preventDefault();

        console.log('activate')

        var $this = $(this),
        	url = $this.attr('href'),
        	l = $this.find('i'),
        	toClass = l.attr('class');

		Agris.swapClass(l,'fa fa-ban fa-check','fa fa-spin fa-spinner');
		Agris.$messageBox.slideUp(100)
        $.get(url,'',function(res){

        	console.log('res', res)

			if( res.status == 1 ){
				toClass = res.active ? 'fa fa-check': 'fa fa-ban';

				if(res.active == undefined){
					$this.closest('td').append('<i class="fa fa-ban"></i>');
					$this.remove();
				}
				Agris.swapClass(l,'fa fa-spin fa-spinner',toClass);
				Agris.swapClass($this,res.active ?'btn-default':'btn-warning',res.active ?'btn-warning':'btn-default');
				
				Agris.alertBox(res.message,'success');
			}


        }).always(function(){
			Agris.swapClass(l,'fa-spin fa-spinner',toClass);
        }).fail(function(error,text,errorThrown){
        	let html = `<p>${error.statusText}</p>`
        	Agris.alertBox(html, 'warning')
        });

    });



    Agris.$container.on('submit', 'form.ajaxDelete', function(e) {
    	e.preventDefault();
    	console.log('deleteing')
    	console.log(e)
    	var c = confirm('Are you sure you want to delete?');



    	if(c) {

    		let form = $(this),
				data = form.serialize(),
				btn = form.find('button[type="submit"]'),
				i = btn.find('i.fa');

			Agris.swapClass(i,'fa fa-trash','fa fa-spin fa-spinner');
			Agris.$messageBox.slideUp(100)
    		$.post(e.target.action, data)
    			.then(res => {
    				// console.log(res)
    				if(res.status == 1) {
    					Agris.alertBox(res.message, 'success')
    					form.closest('tr')
    						.children('td, th')
            				.animate({padding: 0})
            				.wrapInner('<div />')
				            .children()
				            .slideUp(function () {
					            $(this).closest('tr').remove();
					        });
    				}
    			}).always(function(){
					Agris.swapClass(i,'fa-spin fa-spinner','fa-trash');
		        }).fail(function(error,text,errorThrown){
		        	let html = `<p>${error.statusText}</p>`
		        	Agris.alertBox(html, 'warning')
		        });
    	}
    })



    Agris.$body.on('changed.bs.select', 'select.contribution-type', function (e, clickedIndex, isSelected, previousValue) {
		console.log(e)
		console.log(clickedIndex)
		console.log(isSelected)
		console.log(previousValue)
		console.log(e.target.options[clickedIndex].dataset.amount)

		var option = e.target.options[clickedIndex],
			amount = option.dataset.amount
			type = option.value;


		console.log(type)


		if(amount && amount != 0 && type != 3 ) {
			// console.log($('input.contribution_amount'))
			$('input.contribution_amount').val(amount)
		} else {

			$('input.contribution_amount').val(null)
		}

		if( type == 3 ) { // get loan amount and due date
			// console.log($('input.contribution_amount'))
			var member = $('#member_id').val(),
				url = `/member/${member}/loan-amount`,
				loader = $('#loan-payment-loader')


			console.log('member', member)

			if (member) {
				Agris.$messageBox.slideUp()
				loader.css('display', 'block')
				$.get(url)
					.then(data => {
						console.log(data)
						$('input.contribution_amount').val(data)
					}).always(function(){
						loader.css('display', 'none')
			        }).fail(function(error,text,errorThrown){
			        	let html = `<p>${error.statusText}</p>`
        				Agris.alertBox(html, 'warning')
			        });
			} else {
				Agris.alertBox('Please select a member to get member loan amount.', 'info')
			}




		}




	});


	Agris.$body.on('changed.bs.select', 'select#member_id', function (e, clickedIndex, isSelected, previousValue) {
		console.log(e)
		console.log(clickedIndex)
		console.log(isSelected)
		console.log(previousValue)
		console.log(e.target.options[clickedIndex].dataset.amount)

		var type = $('select.contribution-type').val();


		console.log('type', type)


		if( type == 3 ) { // get loan amount and due date
			// console.log($('input.contribution_amount'))
			var member = $('#member_id').val(),
				url = `/member/${member}/loan-amount`,
				loader = $('#loan-payment-loader')

			loader.css('display', 'block')

			console.log('member', member)

			if (member) {
				Agris.$messageBox.slideUp()
				$.get(url)
					.then(data => {
						console.log(data)
						$('input.contribution_amount').val(data)

					}).always(function(){
						loader.css('display', 'none')
			        }).fail(function(error,text,errorThrown){
			        	let html = `<p>${error.statusText}</p>`
        				Agris.alertBox(html, 'warning')
			        });
			} else {
				Agris.alertBox('Please select a member to get member loan amount.', 'info')
			}




			$('input.contribution_amount').val(amount)
		}




	});



















});